// Course: Hardware-oriented programming
// Assignment: 1a
// Student name: Mads Richardt
// Date: 26.08.2022
// Description: A program that prints the string "Programering er en kontaktsport."

#include <stdio.h>

int main(void) {
    char s[] = "Programering er en kontaktsport."; // Initializing string
    printf("%s\n",s); // Printing string to standard output
}
